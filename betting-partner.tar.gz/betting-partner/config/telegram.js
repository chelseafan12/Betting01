module.exports = {
  apiId: 16429034,
  apiHash: 'dbc726a63f042f83fa3591e0a062554f',
  phoneNumber: '+6283829480279',
  password: 'medina',
  signalChannel: 'BTC_60s_prediction'
};