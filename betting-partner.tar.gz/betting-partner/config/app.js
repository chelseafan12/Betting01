module.exports = {
  webUrl: "https://coinryze.org",
  email: 'pruebacoc1997@gmail.com',
  password: 'x9UgLfXWqbaKmBa',
  calculatorUrl: "https://finance.coinryze.org",
};
