/**
 * WARNING: This file is auto-generated.
 *
 * The phase data was collected from the betting calculator based on the current configuration 8 stages and a trade amount of 100.
 * This data includes:
 * - phase: The phase number (1-based index).
 * - betAmount: The amount of the bet in the respective phase.
 * - netProfit: The net profit from the bet in the respective phase.
 *
 * To change the settings or parameters, please modify the configuration in /config/betting.js.
 */
 
module.exports = [
  {
    "phase": 1,
    "betAmount": 0.3,
    "netProfit": 0.28
  },
  {
    "phase": 2,
    "betAmount": 0.6,
    "netProfit": 0.29
  },
  {
    "phase": 3,
    "betAmount": 1.3,
    "netProfit": 0.32
  },
  {
    "phase": 4,
    "betAmount": 2.7,
    "netProfit": 0.38
  },
  {
    "phase": 5,
    "betAmount": 5.7,
    "netProfit": 0.5
  },
  {
    "phase": 6,
    "betAmount": 11.9,
    "netProfit": 0.75
  },
  {
    "phase": 7,
    "betAmount": 25,
    "netProfit": 1.29
  },
  {
    "phase": 8,
    "betAmount": 52.5,
    "netProfit": 2.41
  }
];